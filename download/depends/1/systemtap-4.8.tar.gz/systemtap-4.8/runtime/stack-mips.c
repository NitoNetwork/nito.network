static void __stp_stack_print (struct pt_regs *regs, int verbose, int levels)
{
  /* TODO: fix, it is just stub for now */
}
