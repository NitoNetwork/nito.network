#include <linux/panic_notifier.h>

void* c = & panic_notifier_list;
